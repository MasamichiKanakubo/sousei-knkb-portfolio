# 自己紹介サイト
## 自己紹介サイトの概要
先端社会デザイン創成で作成した自己紹介サイトです。
- 氏名：金久保仁理
- 学籍番号：26002301309

## Deploy Link
https://knkb-portflio.netlify.app/

